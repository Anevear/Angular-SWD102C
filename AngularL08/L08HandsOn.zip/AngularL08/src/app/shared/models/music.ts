export class Music{
         id:string;
         title:string;
         artist:string;
         url:string;
}