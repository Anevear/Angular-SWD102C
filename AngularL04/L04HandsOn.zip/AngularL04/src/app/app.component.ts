import { Component } from '@angular/core';

    @Component({
      selector: 'app-root',
      templateUrl: './app.component.html',
      styleUrls: ['./app.component.css']
    })
    export class AppComponent {
      title = 'Anevear Jamie';
      city = 'Onalaska';
      tag = 'Jack of all trades, for bragging rights... mostly.'
      abtMe = "I'm here for a long time, not a good time. No wait, here for a good time, not a long time. I don't tend to stick around a place if I'm not having a good time; I've had 15 addresses in 5 states over 5 years. I learn quick and I can laugh at anything; I refuse to laugh at the expense of anyone."
    }