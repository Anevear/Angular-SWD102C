export class Task {
         id:number;
         name:string;
         duration:string;
         description:string
}
